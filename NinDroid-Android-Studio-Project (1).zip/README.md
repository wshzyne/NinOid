# NinDroid Android Studio project

**Version:** 0.2.0  
**Target:** Android / ARM64 (`arm64-v8a`)  
**Graphics preference:** Vulkan, with OpenGL ES selectable as a fallback  
**UI:** Kotlin + Jetpack Compose  
**Native layer:** C++ / JNI integration stub

## Included
- Library screen and Android Storage Access Framework document importer
- Per-file detail screen
- Graphics API preference, VSync preference, performance profile
- Basic Vulkan / OpenGL capability reporting
- Native C++ shared-library stub and JNI bridge boundary
- ARM64-only ABI filter

## Build
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Install Android NDK and CMake from SDK Manager.
3. Open this folder in Android Studio.
4. Allow Gradle sync to finish.
5. Select an ARM64 Android device or emulator.
6. Build > Build Bundle(s) / APK(s) > Build APK(s).

A JDK 17-compatible Android Studio setup is recommended.

## Important engine limitation
This project is a functional Android frontend starter, **not a Nintendo Switch emulator**. The C++ library is only an integration stub. No Switch CPU/GPU emulation, game execution, firmware handling, key handling, or audio emulation is implemented. A compatible emulation core must be independently and lawfully sourced, reviewed for its license, integrated, and tested. Do not distribute copyrighted game files, firmware, or encryption keys with this app.

Only import files you are legally entitled to use. NinDroid is an independent project and is not affiliated with or endorsed by Nintendo.
