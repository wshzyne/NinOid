#include <jni.h>
#include <string>

// Integration boundary only. This library is NOT a Nintendo Switch emulator.
// A compatible, legally obtained emulation core must be integrated separately.
extern "C" JNIEXPORT jstring JNICALL
Java_com_cart3r_nindroid_NativeBridge_engineStatus(JNIEnv* env, jobject) {
    return env->NewStringUTF("Native bridge loaded; no emulation core is installed.");
}
