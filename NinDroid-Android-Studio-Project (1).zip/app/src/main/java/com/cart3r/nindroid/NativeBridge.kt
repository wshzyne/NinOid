package com.cart3r.nindroid

object NativeBridge {
    val available: Boolean by lazy {
        try { System.loadLibrary("nindroid_native"); true } catch (_: UnsatisfiedLinkError) { false }
    }
    external fun engineStatus(): String
}
