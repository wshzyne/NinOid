package com.cart3r.nindroid

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF09090D)
private val Panel = Color(0xFF17171F)
private val Red = Color(0xFFFF304F)
private val Muted = Color(0xFF9A9AA7)
private val White = Color(0xFFF5F5F7)

data class GameEntry(val name: String, val uri: Uri, val location: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NinDroidApp() }
    }
}

@Composable
fun NinDroidApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("nindroid", 0) }
    val games = remember { mutableStateListOf<GameEntry>() }
    var page by remember { mutableStateOf("Library") }
    var selected by remember { mutableStateOf<GameEntry?>(null) }
    var graphics by remember { mutableStateOf(prefs.getString("graphics", "Vulkan") ?: "Vulkan") }
    var vsync by remember { mutableStateOf(prefs.getBoolean("vsync", true)) }
    var performance by remember { mutableStateOf(prefs.getString("performance", "Balanced") ?: "Balanced") }
    var showAbout by remember { mutableStateOf(false) }

    fun displayName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "Imported game file"
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) name = c.getString(idx) ?: name
        }
        return name
    }

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val name = displayName(uri)
            if (games.none { it.uri == uri }) games.add(GameEntry(name, uri, uri.toString()))
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Red, background = Ink, surface = Panel, onBackground = White,
        onSurface = White, secondary = Muted
    )) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            Column(Modifier.fillMaxSize()) {
                TopBar()
                when (page) {
                    "Library" -> LibraryScreen(games, onImport = { importer.launch(arrayOf("*/*")) }, onSelect = { selected = it; page = "Game details" })
                    "Settings" -> SettingsScreen(graphics, { graphics = it; prefs.edit().putString("graphics", it).apply() },
                        vsync, { vsync = it; prefs.edit().putBoolean("vsync", it).apply() },
                        performance, { performance = it; prefs.edit().putString("performance", it).apply() })
                    "System" -> SystemScreen(context.packageManager)
                    "Game details" -> selected?.let { GameDetails(it, onBack = { page = "Library" }) } ?: LibraryScreen(games, { importer.launch(arrayOf("*/*")) }, { selected = it })
                    else -> LibraryScreen(games, { importer.launch(arrayOf("*/*")) }, { selected = it })
                }
                Spacer(Modifier.weight(1f))
                NavigationBar(containerColor = Panel, contentColor = White) {
                    listOf("Library", "Settings", "System").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = {
                                Icon(when(item) {
                                    "Library" -> Icons.Default.SportsEsports
                                    "Settings" -> Icons.Default.Tune
                                    else -> Icons.Default.Memory
                                }, contentDescription = item)
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Red, selectedTextColor = Red, indicatorColor = Red.copy(alpha=.15f))
                        )
                    }
                }
            }
            if (showAbout) AlertDialog(onDismissRequest = { showAbout = false }, confirmButton = {
                TextButton(onClick = { showAbout = false }) { Text("Close") }
            }, title = { Text("About NinDroid") }, text = { Text("NinDroid is an independent Android frontend project. It is not affiliated with or endorsed by Nintendo.") })
        }
    }
}

@Composable
private fun TopBar() {
    Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).background(Red, RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.SportsEsports, null, tint = Color.White)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("NINDROID", fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("ANDROID EMULATION FRONTEND", fontSize = 9.sp, color = Muted, letterSpacing = 1.4.sp)
        }
        Text("0.2.0", color = Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ScreenTitle(title: String, subtitle: String) {
    Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 16.dp)) {
        Text(title, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun LibraryScreen(games: List<GameEntry>, onImport: () -> Unit, onSelect: (GameEntry) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        ScreenTitle("Your library", "Manage your locally stored game files")
        Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${games.size} FILES", color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
            Button(onClick = onImport, colors = ButtonDefaults.buttonColors(containerColor = Red), shape = RoundedCornerShape(12.dp)) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Import")
            }
        }
        Spacer(Modifier.height(16.dp))
        if (games.isEmpty()) {
            Column(Modifier.fillMaxWidth().padding(28.dp).background(Panel, RoundedCornerShape(20.dp)).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.FolderOpen, null, tint = Red, modifier = Modifier.size(42.dp))
                Spacer(Modifier.height(12.dp))
                Text("Your library is empty", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("Import a game file you are legally entitled to use.", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(14.dp))
                OutlinedButton(onClick = onImport) { Text("Choose file") }
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(games) { game ->
                    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { onSelect(game) }.padding(15.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(48.dp).background(Color(0xFF29202A), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.SportsEsports, null, tint = Red)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(game.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text("Local document · tap for details", color = Muted, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Muted)
                    }
                }
            }
        }
        InfoBanner("ENGINE NOT INSTALLED", "The library is ready. Game launching becomes available only after a compatible emulation core is integrated.")
    }
}

@Composable
private fun InfoBanner(title: String, message: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp).background(Color(0xFF28171D), RoundedCornerShape(12.dp)).padding(13.dp)) {
        Icon(Icons.Default.Info, null, tint = Red)
        Spacer(Modifier.width(10.dp))
        Column {
            Text(title, color = Red, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(message, color = White, fontSize = 11.sp)
        }
    }
}

@Composable
private fun GameDetails(game: GameEntry, onBack: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(20.dp)) {
        TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Text(" Back to library") }
        Spacer(Modifier.height(12.dp))
        Icon(Icons.Default.SportsEsports, null, tint = Red, modifier = Modifier.size(54.dp))
        Spacer(Modifier.height(12.dp))
        Text(game.name, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Imported document", color = Muted)
        Spacer(Modifier.height(18.dp))
        Text("FILE LOCATION", color = Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(game.location, fontSize = 11.sp, color = Muted)
        Spacer(Modifier.height(20.dp))
        InfoBanner("CANNOT LAUNCH YET", "NinDroid does not currently contain a Switch emulation core. This entry is stored in your library only.")
    }
}

@Composable
private fun SettingsScreen(graphics: String, onGraphics: (String) -> Unit, vsync: Boolean, onVsync: (Boolean) -> Unit,
                           performance: String, onPerformance: (String) -> Unit) {
    Column {
        ScreenTitle("Settings", "Tune the frontend and graphics preferences")
        Column(Modifier.padding(horizontal = 20.dp).background(Panel, RoundedCornerShape(16.dp)).padding(16.dp)) {
            Text("GRAPHICS API", color = Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            listOf("Vulkan", "OpenGL ES").forEach { api ->
                Row(Modifier.fillMaxWidth().clickable { onGraphics(api) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(api, Modifier.weight(1f))
                    RadioButton(selected = graphics == api, onClick = { onGraphics(api) }, colors = RadioButtonDefaults.colors(selectedColor = Red))
                }
            }
            HorizontalDivider(color = Color.DarkGray)
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("VSync"); Text("Frontend preference", color = Muted, fontSize = 11.sp) }
                Switch(checked = vsync, onCheckedChange = onVsync, colors = SwitchDefaults.colors(checkedThumbColor = Red))
            }
            HorizontalDivider(color = Color.DarkGray)
            Spacer(Modifier.height(12.dp))
            Text("PERFORMANCE PROFILE", color = Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            listOf("Battery saver", "Balanced", "Performance").forEach { mode ->
                Row(Modifier.fillMaxWidth().clickable { onPerformance(mode) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(mode, Modifier.weight(1f))
                    RadioButton(selected = performance == mode, onClick = { onPerformance(mode) }, colors = RadioButtonDefaults.colors(selectedColor = Red))
                }
            }
        }
        InfoBanner("NOTE", "These are saved frontend preferences. They do not change GPU behavior until an emulation core is connected.")
    }
}

@Composable
private fun SystemScreen(pm: PackageManager) {
    val vulkan = pm.hasSystemFeature("android.hardware.vulkan.version")
    val gles = pm.getSystemAvailableFeatures().firstOrNull { it.name == null }?.version ?: 0
    Column {
        ScreenTitle("System status", "Device capability checks")
        Column(Modifier.padding(horizontal = 20.dp).background(Panel, RoundedCornerShape(16.dp)).padding(16.dp)) {
            StatusRow("Target architecture", "ARM64 only", true)
            StatusRow("Vulkan feature", if (vulkan) "Available" else "Not reported", vulkan)
            StatusRow("OpenGL ES", if (gles >= 3) "3.x supported" else "Check device support", gles >= 3)
            StatusRow("Native bridge", "Integration stub", false)
            StatusRow("Emulation engine", "Not installed", false)
        }
        Spacer(Modifier.height(14.dp))
        InfoBanner("DIAGNOSTICS", "Capability detection is preliminary. Actual graphics support and game compatibility require testing on the target device.")
        Text("NinDroid is an independent project and is not affiliated with Nintendo.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(20.dp))
    }
}

@Composable
private fun StatusRow(label: String, value: String, good: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, fontWeight = FontWeight.Medium)
            Text(value, color = Muted, fontSize = 11.sp)
        }
        Icon(if (good) Icons.Default.CheckCircle else Icons.Default.Info, null, tint = if (good) Color(0xFF55C98A) else Red)
    }
}
